local npcid = 90030
    local function OnGossipHello(event, player, object, unit)  -- Menu Principal 1
            player:GossipClearMenu()
            player:GossipMenuAddItem(5, "Je souhaiterais m'enchanter", 0,  50)
            player:GossipMenuAddItem(1, "On m'as dit que vous aviez des gemmes", 0,  101)
            object:SendUnitSay("Salutation " .. player:GetName(), 0)
            object:Emote(1)
            player:GossipSendMenu(1, object, MenuId)
    end

    -- DOCUMENTATION SLOT ID
    local inv_slots ={
        [0] = "Tête",
        [2] = "Epaules",
        [4] = "Torse",
        [5] = "Ceinture",
        [6] = "Jambes",
        [7] = "Pieds",
        [8] = "Poignets",
        [9] = "Mains",
        [14] = "Dos",
        [15] = "Main Droite",
        [16] = "Main Gauche",
        [17] = "A distance"
    }


    local function OnGossipSelect(event, player, object, sender, intid, code, menuid, unit)

        if (intid == 50) then -- Séléction 1
            player:GossipClearMenu() 
            player:GossipMenuAddItem(5, "Armures", 0,  10)
            player:GossipMenuAddItem(9, "Armes", 0,  20)
            player:GossipMenuAddItem(0, "Menu Principal", 0,  70)
            player:GossipSendMenu(1, object, MenuId)
        end

        if (intid == 101) then 
            player:SendListInventory(object)
        end

        if (intid == 70) then -- Menu Principal 2
            player:GossipClearMenu()
            player:GossipMenuAddItem(5, "Je souhaiterais m'enchanter", 0,  50)
            player:GossipMenuAddItem(1, "On m'as dit que vous aviez des gemmes", 0,  101)
            player:GossipSendMenu(1, object, MenuId)
        end

        if (intid == 10) then -- Séléction 2
            player:GossipClearMenu()
            player:GossipMenuAddItem(5, "|TInterface/paperdoll/UI-PaperDoll-Slot-Head:17:17:-25|tTête", 0,  110)
            player:GossipMenuAddItem(5, "|TInterface/paperdoll/UI-PaperDoll-Slot-Shoulder:17:17:-25|tÉpaules", 0,  120)
            player:GossipMenuAddItem(5, "|TInterface/paperdoll/UI-PaperDoll-Slot-Chest:17:17:-25|tTorse", 0,  130)
            player:GossipMenuAddItem(5, "|TInterface/paperdoll/UI-PaperDoll-Slot-Wrists:17:17:-25|tPoignets", 0,  140)
            player:GossipMenuAddItem(5, "|TInterface/paperdoll/UI-PaperDoll-Slot-Hands:17:17:-25|tMains", 0,  150)
            player:GossipMenuAddItem(5, "|TInterface/paperdoll/UI-PaperDoll-Slot-Waist:17:17:-25|tTaille", 0,  160)
            player:GossipMenuAddItem(5, "|TInterface/paperdoll/UI-PaperDoll-Slot-Legs:17:17:-25|tJambes", 0,  170)
            player:GossipMenuAddItem(5, "|TInterface/paperdoll/UI-PaperDoll-Slot-Feet:17:17:-25|tPieds", 0,  180)
            player:GossipMenuAddItem(5, "|TInterface/paperdoll/UI-PaperDoll-Slot-Chest:17:17:-25|tDos", 0,  190)
            player:GossipMenuAddItem(5, "Supprimer mes enchantements actuel", 0,  200)
            player:GossipMenuAddItem(0, "Retour", 0,  50)
            player:GossipSendMenu(1, object, MenuId)
        end

        if (intid == 200) then -- Suppression Tête
            item = player:GetItemByPos(255, 0)
            if (item == nil or item:GetEnchantmentId(0) <= 0) then
                player:SendNotification("Vous n'avez pas d'enchantement de casques")
                player:GossipComplete()
            else
            item:ClearEnchantment(0)
            player:SendNotification("Votre enchantement de casque a était supprimés")
            player:GossipMenuAddItem(0, "", 0,  50)
            player:GossipSendMenu(1, object, MenuId)
            end
        end



        if (intid == 20) then -- Séléction 3
            player:GossipClearMenu()
            player:GossipMenuAddItem(9, "Tenue en main droite", 0,  190)
            player:GossipMenuAddItem(9, "Tenue en main gauche", 0,  200)
            player:GossipMenuAddItem(0, "Retour", 0,  50)
            player:GossipSendMenu(1, object, MenuId)
        end

        if (intid == 111) then -- Suppression Tête
            item = player:GetItemByPos(255, 0)
            if (item == nil or item:GetEnchantmentId(0) <= 0) then
                player:SendNotification("Vous n'avez pas d'enchantement de casques")
                player:GossipComplete()
            else
            item:ClearEnchantment(0)
            player:SendNotification("Votre enchantement de casque a était supprimés")
            player:GossipMenuAddItem(0, "", 0,  50)
            player:GossipSendMenu(1, object, MenuId)
            end
        end

        if (intid == 110) then -- Choix Enchantement Tête
            player:GossipClearMenu() 
            player:GossipMenuAddItem(5, "|TInterface/ICONS/ability_warrior_shieldmastery:17:17:-25|tArcanum de triomphe", 0,  1101, false, "+50 à la puissance d'attaque et +20 au score de résilience") -- 3795
            player:GossipMenuAddItem(5, "|TInterface/ICONS/spell_arcane_arcaneresilience:17:17:-25|tArcanum de domination", 0,  1102, false, "+29 à la puissance des sorts et +20 au score de résilience") -- 3797
            player:GossipMenuAddItem(5, "|TInterface/ICONS/ability_warrior_rampage:17:17:-25|tArcanum de tourment", 0,  1103, false, "+50 à la puissance d'attaque et +20 au score de coup critique") -- 3817
            player:GossipMenuAddItem(5, "|TInterface/ICONS/ability_warrior_swordandboard:17:17:-25|tArcanum du fidèle protecteur", 0,  1104, false, "+37 Endurance et +20 au score de défense") -- 3818
            player:GossipMenuAddItem(5, "|TInterface/ICONS/ability_warrior_shieldmastery:17:17:-25|tArcanum de guérison bienheureuse", 0,  1105, false, "+30 à la puissance des sorts et 10 points de mana toutes les 5 secondes") -- 3819
            player:GossipMenuAddItem(5, "|TInterface/ICONS/spell_fire_masterofelements:17:17:-25|tArcanum des mystères ardents", 0,  1106, false, "+30 à la puissance des sorts et 20 au score de coup critique") -- 3820
            player:GossipMenuAddItem(5, "|TInterface/ICONS/ability_warrior_shieldmastery:17:17:-25|tArcanum du gladiateur sauvage", 0,  1107, false, "+30 Endurance et +25 score de résilience") -- 3842
            player:GossipMenuAddItem(0, "Retour", 0,  10)
            player:GossipSendMenu(1, object, MenuId)
        end
        if (intid == 1101) then -- Arcanum de triomphe
            item = player:GetItemByPos(255, 0)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de casque d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3795, 0)
                object:SendUnitSay("Votre casque est maintenant enchantés", 0)
                player:GossipClearMenu() 
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1102) then -- Arcanum de domination
            item = player:GetItemByPos(255, 0)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de casque d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3797, 0)
                object:SendUnitSay("Votre casque est maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1103) then -- Arcanum de tourment
            item = player:GetItemByPos(255, 0)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de casque d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3817, 0)
                object:SendUnitSay("Votre casque est maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1104) then -- Arcanum du fidèle protecteur
            item = player:GetItemByPos(255, 0)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de casque d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3818, 0)
                object:SendUnitSay("Votre casque est maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1105) then -- Arcanum de guérison bienheureuse
            item = player:GetItemByPos(255, 0)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de casque d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3819, 0)
                object:SendUnitSay("Votre casque est maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1106) then -- Arcanum des mystères ardents
            item = player:GetItemByPos(255, 0)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de casque d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3820, 0)
                object:SendUnitSay("Votre casque est maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1107) then -- Arcanum du gladiateur sauvage
            item = player:GetItemByPos(255, 0)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de casque d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3842, 0)
                object:SendUnitSay("Votre casque est maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end

        if (intid == 120) then -- Choix Enchantement Epaules
            player:GossipClearMenu() 
            player:GossipMenuAddItem(5, "|TInterface/ICONS/spell_holy_weaponmastery:17:17:-25|tCalligraphie de triomphe", 0,  1108, false, "+40 à la puissance d'attaque et +15 au score de résilience") -- 3793
            player:GossipMenuAddItem(5, "|TInterface/ICONS/spell_holy_powerinfusion:17:17:-25|tCalligraphie de domination", 0,  1109, false, "+23 à la puissance des sorts et +15 au score de résilience") -- 3794
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_axe_85:17:17:-25|tCalligraphie supérieure de la hache", 0,  1110, false, "+40 à la puissance d'attaque et +15 au score de coup critique") -- 3808
            player:GossipMenuAddItem(5, "|TInterface/ICONS/spell_arcane_teleportorgrimmar:17:17:-25|tCalligraphie supérieure de la roche", 0,  1111, false, "+24 à la puissance des sorts et +8 points de mana par tranche de 5 secondes") -- 3809
            player:GossipMenuAddItem(5, "|TInterface/ICONS/spell_nature_lightningoverload:17:17:-25|tCalligraphie supérieure de l'orage", 0,  1112, false, "+24 à la puissance des sorts et +15 au score de coup critique") -- 3810
            player:GossipMenuAddItem(5, "|TInterface/ICONS/spell_holy_divinepurpose:17:17:-25|tCalligraphie supérieure du pinacle", 0,  1113, false, "+20 au score d'esquive et +15 au score de défense") -- 3811
            player:GossipMenuAddItem(0, "Retour", 0,  10)
            player:GossipSendMenu(1, object, MenuId)
        end

        if (intid == 1108) then -- Calligraphie de triomphe
            item = player:GetItemByPos(255, 2)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas d'épaulières d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3793, 0)
                object:SendUnitSay("Vos épaulières sont maintenant enchantés", 0)
                player:GossipClearMenu() 
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1109) then -- Calligraphie de domination
            item = player:GetItemByPos(255, 2)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas d'épaulières d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3794, 0)
                object:SendUnitSay("Vos épaulières sont maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1110) then -- Calligraphie supérieure de la hache
            item = player:GetItemByPos(255, 2)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas d'épaulières d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3808, 0)
                object:SendUnitSay("Vos épaulières sont maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1111) then -- Calligraphie supérieure de la roche
            item = player:GetItemByPos(255, 2)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas d'épaulières d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3809, 0)
                object:SendUnitSay("Vos épaulières sont maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1112) then -- Calligraphie supérieure de l'orage
            item = player:GetItemByPos(255, 2)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas d'épaulières d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3810, 0)
                object:SendUnitSay("Vos épaulières sont maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1113) then -- Calligraphie supérieure du pinacle
            item = player:GetItemByPos(255, 2)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas d'épaulières d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3811, 0)
                object:SendUnitSay("Vos épaulières sont maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end

        if (intid == 130) then -- Choix Enchantement Torse
            player:GossipClearMenu() 
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tSuper santé", 0,  1114, false, "inv_misc_enchantedscroll") -- 3297
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tCaractéristiques puissantes", 0,  1115, false, "+10 à toutes les caractéristiques") -- 3832
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tRésilience exceptionnelle", 0,  1116, false, "+20 au score de résilience") -- 3245
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tEsquive supérieure", 0,  1117, false, "+22 au score de défense") -- 1953
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tEsprit supérieure", 0,  1118, false, "+20 Esprit") -- 1149
            player:GossipMenuAddItem(0, "Retour", 0,  10)
            player:GossipSendMenu(1, object, MenuId)
        end

        if (intid == 1114) then -- Super santé
            item = player:GetItemByPos(255, 4)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de plastron d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3297, 0)
                object:SendUnitSay("Votre plastron est maintenant enchantés", 0)
                player:GossipClearMenu() 
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1115) then -- Caractéristiques puissantes
            item = player:GetItemByPos(255, 4)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de plastron d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3832, 0)
                object:SendUnitSay("Votre plastron est maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1116) then -- Résilience exceptionnelle
            item = player:GetItemByPos(255, 4)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de plastron d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3245, 0)
                object:SendUnitSay("Votre plastron est maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1117) then -- Esquive supérieure
            item = player:GetItemByPos(255, 4)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de plastron d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(1953, 0)
                object:SendUnitSay("Votre plastron est maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1118) then -- Esprit supérieure
            item = player:GetItemByPos(255, 4)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de plastron d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(1149, 0)
                object:SendUnitSay("Votre plastron est maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end

        if (intid == 140) then -- Choix Enchantement Poignet
            player:GossipClearMenu() 
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tFrappe", 0,  1119, false, "+38 à la puissance d'attaque") -- 1600
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tPuissance des sorts excellente", 0,  1120, false, "+30 à la puissance des sorts") -- 2332
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tEsprit majeur", 0,  1121, false, "+18 Esprit") -- 1147
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tIntelligence exceptionnelle", 0,  1122, false, "+16 Intelligence") -- 1119
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tEndurance supérieure", 0,  1123, false, "+40 Endurance") -- 1093
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tExpertise supérieure", 0,  1124, false, "+15 au score d'expertise") -- 3231
            player:GossipMenuAddItem(0, "Retour", 0,  10)
            player:GossipSendMenu(1, object, MenuId)
        end

        if (intid == 1119) then -- Frappe
            item = player:GetItemByPos(255, 8)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de brassards d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(1600, 0)
                object:SendUnitSay("Vos brassards sont maintenant enchantés", 0)
                player:GossipClearMenu() 
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1120) then -- Puissance des sorts excellente
            item = player:GetItemByPos(255, 8)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de brassards d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(2332, 0)
                object:SendUnitSay("Vos brassards sont maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1121) then -- Esprit majeur
            item = player:GetItemByPos(255, 8)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de brassards d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(1147, 0)
                object:SendUnitSay("Vos brassards sont maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1122) then -- Intelligence exceptionnelle
            item = player:GetItemByPos(255, 8)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de brassards d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(1119, 0)
                object:SendUnitSay("Vos brassards sont maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1123) then -- Endurance supérieure
            item = player:GetItemByPos(255, 8)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de brassards d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(1093, 0)
                object:SendUnitSay("Vos brassards sont maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1124) then -- Expertise supérieure
            item = player:GetItemByPos(255, 8)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de brassards d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3231, 0)
                object:SendUnitSay("Vos brassards sont maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end

        if (intid == 150) then -- Choix Enchantement Mains
            player:GossipClearMenu() 
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tEndurance supérieure", 0,  1125, false, "+40 Endurance") -- 1093
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tPuissance des sorts excellente", 0,  1126, false, "+28 à la puissance des sorts") -- 2330
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tAgilité majeur", 0,  1127, false, "+20 Agilité") -- 1097
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tPrécision", 0,  1128, false, "+20 au score de toucher") -- 3234
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tExpertise supérieure", 0,  1129, false, "+15 au score d'expertise") -- 3231
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tMenace", 0,  1130, false, "+2% à la menace") -- 2613
            player:GossipMenuAddItem(0, "Retour", 0,  10)
            player:GossipSendMenu(1, object, MenuId)
        end

        if (intid == 1125) then -- Endurance supérieure
            item = player:GetItemByPos(255, 9)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de gants d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(1093, 0)
                object:SendUnitSay("Vos gants sont maintenant enchantés", 0)
                player:GossipClearMenu() 
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1126) then -- Puissance des sorts excellente
            item = player:GetItemByPos(255, 9)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de gants d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(2330, 0)
                object:SendUnitSay("Vos gants sont maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1127) then -- Agilité majeur
            item = player:GetItemByPos(255, 9)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de gants d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(1097, 0)
                object:SendUnitSay("Vos gants sont maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1128) then -- Précision
            item = player:GetItemByPos(255, 9)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de gants d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3234, 0)
                object:SendUnitSay("Vos gants sont maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1129) then -- Expertise supérieure
            item = player:GetItemByPos(255, 9)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de gants d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3231, 0)
                object:SendUnitSay("Vos gants sont maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1130) then -- Menace
            item = player:GetItemByPos(255, 9)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de gants d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(2613, 0)
                object:SendUnitSay("Vos gants sont maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end

        if (intid == 160) then -- Choix Enchantement Taille
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_belt_36:17:17:-25|tBoucle de ceinture éternelle", 0,  1131, false, "Ajoute de manière permanente une boucle de ceinture éternelle à une ceinture, ce qui ajoute une châsse sur celle-ci.") -- 3729
            player:GossipMenuAddItem(0, "Retour", 0,  10)
            player:GossipSendMenu(1, object, MenuId)
        end
        
        if (intid == 1131) then -- Boucle de ceinture éternelle
            item = player:GetItemByPos(255, 5)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de ceinture d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3729, 0)
                object:SendUnitSay("Votre ceinture est maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end

        if (intid == 170) then -- Choix Enchantement Jambes
            player:GossipClearMenu() 
            player:GossipMenuAddItem(5, "|TInterface/ICONS/trade_leatherworking:17:17:-25|tRenforts de jambe du jormungar", 0,  1132, false, "+55 Endurance et +22 Agilité") -- 3327
            player:GossipMenuAddItem(5, "|TInterface/ICONS/trade_leatherworking:17:17:-25|tRenforts de jambe nérubiens", 0,  1133, false, "+75 à la puissance d'attaque et +22 au score de coup critique") -- 3328
            player:GossipMenuAddItem(5, "|TInterface/ICONS/spell_nature_astralrecalgroup:17:17:-25|tFil ensorcelé de maître", 0,  1134, false, "+50 à la puissance des sorts et +30 à l'Endurance") -- 3873
            player:GossipMenuAddItem(5, "|TInterface/ICONS/spell_nature_astralrecalgroup:17:17:-25|tFil ensorcelé sanctifié", 0,  1135, false, "+50 à la puissance des sorts et +20 à l'Esprit") -- 3872
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_armorkit_18:17:17:-25|tArmure de jambe terrestre", 0,  1136, false, "+28 Endurance et +40 au score de résilience") -- 3853
            player:GossipMenuAddItem(0, "Retour", 0,  10)
            player:GossipSendMenu(1, object, MenuId)
        end

        if (intid == 1132) then -- Renforts de jambe du jormungar
            item = player:GetItemByPos(255, 6)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de jambières d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3327, 0)
                object:SendUnitSay("Vos jambières sont maintenant enchantés", 0)
                player:GossipClearMenu() 
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1133) then -- Renforts de jambe nérubiens
            item = player:GetItemByPos(255, 6)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de jambières d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3328, 0)
                object:SendUnitSay("Vos jambières sont maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1134) then -- Fil ensorcelé de maître
            item = player:GetItemByPos(255, 6)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de jambières d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3873, 0)
                object:SendUnitSay("Vos jambières sont maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1135) then -- Fil ensorcelé sanctifié
            item = player:GetItemByPos(255, 6)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de jambières d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3872, 0)
                object:SendUnitSay("Vos jambières sont maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1136) then -- Armure de jambe terrestre
            item = player:GetItemByPos(255, 6)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de jambières d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3853, 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
                object:SendUnitSay("Vos jambières sont maintenant enchantés", 0)
            end
        end

        if (intid == 180) then -- Choix Enchantement Pieds
            player:GossipClearMenu() 
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tAssaut supérieur", 0,  1137, false, "+32 à la puissance d'attaque") -- 1597
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tRobustesse supérieure", 0,  1138, false, "+22 Endurance") -- 1075
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tVitalité supérieure", 0,  1139, false, "+7 points de vie et de mana toutes les 5 sec") -- 3244
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tEsprit majeur", 0,  1140, false, "+18 Esprit") -- 1147
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tVitalité rohart", 0,  1141, false, "+15 Endurance et augmentation mineure de la vitesse") -- 3232
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tMarcheglace", 0,  1142, false, "+12 au score de toucher et +12 au score de coup critique") -- 3826
            player:GossipMenuAddItem(0, "Retour", 0,  10)
            player:GossipSendMenu(1, object, MenuId)
        end

        if (intid == 1137) then -- Assaut supérieur
            item = player:GetItemByPos(255, 7)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de bottes d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(1597, 0)
                object:SendUnitSay("Vos bottes sont maintenant enchantés", 0)
                player:GossipClearMenu() 
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1138) then -- Robustesse supérieure
            item = player:GetItemByPos(255, 7)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de bottes d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(1075, 0)
                object:SendUnitSay("Vos bottes sont maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1139) then -- Vitalité supérieure
            item = player:GetItemByPos(255, 7)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de bottes d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3244, 0)
                object:SendUnitSay("Vos bottes sont maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1140) then -- Esprit majeur
            item = player:GetItemByPos(255, 7)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de bottes d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(1147, 0)
                object:SendUnitSay("Vos bottes sont maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1141) then -- Vitalité rohart
            item = player:GetItemByPos(255, 7)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de bottes d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3232, 0)
                object:SendUnitSay("Vos bottes sont maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1142) then -- Marcheglace
            item = player:GetItemByPos(255, 7)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de bottes d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3826, 0)
                object:SendUnitSay("Vos bottes sont maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end

        if (intid == 190) then -- Choix Enchantement Dos
            player:GossipClearMenu() 
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tAgilité majeure", 0,  1143, false, "+22 Agilité") -- 1099
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tDéfense", 0,  1144, false, "+16 au score de défense") -- 1951
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tPuissance mineure", 0,  1145, false, "+35 à la pénétration des sorts") -- 3243
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tVitesse supérieure", 0,  1146, false, "+23 au score de hâte") -- 3831
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tArmure puissante", 0,  1147, false, "+225 Armure") -- 3294
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tSagesse", 0,  1148, false, "+10 Esprit et menace réduite de 2%") -- 3296
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tCamouflage", 0,  1149, false, "Camouflage augmenté") -- 910
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tRésistance au Feu excellente", 0,  1150, false, "+20 à la résistance au Feu") -- 1354
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tRésistance à l'Ombre excellente", 0,  1151, false, "+20 à la résistance à l'Ombre") -- 1446
            player:GossipMenuAddItem(5, "|TInterface/ICONS/inv_misc_enchantedscroll:17:17:-25|tRésistance aux Arcanes excellente", 0,  1152, false, "+20 à la résistance aux Arcanes") -- 1262
            player:GossipMenuAddItem(0, "Retour", 0,  10)
            player:GossipSendMenu(1, object, MenuId)
        end

        if (intid == 1143) then -- Agilité majeure
            item = player:GetItemByPos(255, 14)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de cape d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(1099, 0)
                object:SendUnitSay("Votre cape est maintenant enchantés", 0)
                player:GossipClearMenu() 
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1144) then -- Défense
            item = player:GetItemByPos(255, 14)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de cape d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(1951, 0)
                object:SendUnitSay("Votre cape est maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1145) then -- Puissance mineure
            item = player:GetItemByPos(255, 14)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de cape d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3243, 0)
                object:SendUnitSay("Votre cape est maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1146) then -- Vitesse supérieure
            item = player:GetItemByPos(255, 14)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de cape d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3831, 0)
                object:SendUnitSay("Votre cape est maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1147) then -- Armure puissante
            item = player:GetItemByPos(255, 14)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de cape d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3294, 0)
                object:SendUnitSay("Votre cape est maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1148) then -- Sagesse
            item = player:GetItemByPos(255, 14)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de cape d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(3296, 0)
                object:SendUnitSay("Votre cape est maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1149) then -- Camouflage
            item = player:GetItemByPos(255, 14)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de cape d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(910, 0)
                object:SendUnitSay("Votre cape est maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1150) then -- Résistance au Feu excellente
            item = player:GetItemByPos(255, 14)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de cape d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(1354, 0)
                object:SendUnitSay("Votre cape est maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1151) then -- Résistance à l'Ombre excellente
            item = player:GetItemByPos(255, 14)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de cape d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(1446, 0)
                object:SendUnitSay("Votre cape est maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
        if (intid == 1152) then -- Résistance aux Arcanes excellente
            item = player:GetItemByPos(255, 14)
            if (item == nil) then
                object:SendUnitSay("Vous n'avez pas de cape d'équippés", 0)
                player:GossipComplete()
            else
                item:SetEnchantment(1262, 0)
                object:SendUnitSay("Votre cape est maintenant enchantés", 0)
                player:GossipMenuAddItem(5, "", 0,  10) -- Retour Séléction 2 AUTOMATIQUE
                player:GossipSendMenu(1, object, MenuId)
            end
        end
    end   
RegisterCreatureGossipEvent(npcid, 1, OnGossipHello)
RegisterCreatureGossipEvent(npcid, 2, OnGossipSelect)