local npcid = 90031

    local function OnGossipHello(event, player, object)
            player:GossipMenuAddItem(3, "J'aimerais apprendre mes sorts", 0,  100)
            player:GossipMenuAddItem(9, "Je voudrais maîtriser de nouvelles armes.", 0, 101)
            player:GossipMenuAddItem(7, "Réinitialiser mes points de talent", 0, 102)
            player:GossipMenuAddItem(7, "En savoir plus sur la double spécialisation", 0, 103)
            object:SendUnitSay("Bonjour ".. player:GetClassAsString(player:GetDbcLocale()), 0)
            player:GossipSendMenu(1, object, MenuId)
            object:Emote(1)
    end

    local function OnGossipSelect(event, player, object, sender, intid, code, menuid, unit)
        if (intid == 100) then
            player:SendTrainerList(object)
        end
            if (intid == 101) then
                player:LearnSpell(264)
                player:LearnSpell(5011)
                player:LearnSpell(1180)
                player:LearnSpell(15590)
                player:LearnSpell(266)
                player:LearnSpell(196)
                player:LearnSpell(198)
                player:LearnSpell(201)
                player:LearnSpell(200)
                player:LearnSpell(5019)
                player:LearnSpell(227)
                player:LearnSpell(2764)
                player:LearnSpell(2567)
                player:LearnSpell(197)
                player:LearnSpell(199)
                player:LearnSpell(202)
                player:LearnSpell(5009)
                player:AdvanceSkill (43, 399) 
                player:AdvanceSkill (44, 399) 
                player:AdvanceSkill (45, 399)
                player:AdvanceSkill (46, 399) 
                player:AdvanceSkill (54, 399) 
                player:AdvanceSkill (55, 399) 
                player:AdvanceSkill (95, 399) 
                player:AdvanceSkill (136, 399) 
                player:AdvanceSkill (160, 399) 
                player:AdvanceSkill (162, 399) 
                player:AdvanceSkill (172, 399)
                player:AdvanceSkill (173, 399) 
                player:AdvanceSkill (176, 399) 
                player:AdvanceSkill (226, 399) 
                player:AdvanceSkill (228, 399) 
                player:AdvanceSkill (229, 399) 
                player:AdvanceSkill (473, 399)
                player:GossipComplete()
                object:SendUnitSay("Vous voilà passer maître dans le maniement de n'importe quelle armes", 0)
                object:Emote(1)
            end
            if (intid == 102) then
                player:SendNotification("Vos talents sont réinitialisés")
                player:ResetTalents()
                player:GossipComplete()
            end
            if (intid == 103) then
                player:CastSpell(player, 63624)
                player:GossipComplete()
                object:SendUnitSay("Bien joué, vous venez d'apprendre la double spécialisation", 0)
                object:Emote(1)
            end
end
RegisterCreatureGossipEvent(npcid, 1, OnGossipHello)
RegisterCreatureGossipEvent(npcid, 2, OnGossipSelect)