local npcid = 90032

    local function OnGossipHello(event, player, object, unit)
            player:GossipClearMenu()
            player:GossipMenuAddItem(3, "Je souhaiterais apprendre ..", 0,  17)
            player:GossipMenuAddItem(5, "Monter mon métier à 450", 0,  18)
            player:GossipSendMenu(90131, object, MenuId)
            object:SendUnitSay("Bien le bonjour " .. player:GetName(), 0)
            object:Emote(1)

    end

    local function OnGossipSelect(event, player, object, sender, intid, code, menuid, unit)
        
        if (intid == 999) then
            player:GossipClearMenu()
            player:GossipMenuAddItem(3, "Je souhaiterais apprendre", 0,  17)
            player:GossipMenuAddItem(5, "Monter mon métier à 450", 0,  18)
            player:GossipSendMenu(90131, object, MenuId)
        end
        
        if (intid == 17) then -- Métiers
            player:GossipMenuAddItem(5, "Alchimie", 0, 100)
            player:GossipMenuAddItem(5, "Forge", 0, 101)
            player:GossipMenuAddItem(5, "Enchantement", 0, 102)
            player:GossipMenuAddItem(5, "Ingénierie", 0, 103)
            player:GossipMenuAddItem(5, "Herboristerie", 0, 104)
            player:GossipMenuAddItem(5, "Calligraphie", 0, 105)
            player:GossipMenuAddItem(5, "Joaillerie", 0, 106)
            player:GossipMenuAddItem(5, "Travail du cuir", 0, 107)
            player:GossipMenuAddItem(5, "Minage", 0, 108)
            player:GossipMenuAddItem(5, "Dépeçage", 0, 109)
            player:GossipMenuAddItem(5, "Couture", 0, 110)
            player:GossipMenuAddItem(0, "Métiers secondaire", 0, 111)
            player:GossipMenuAddItem(0, "Menu principal", 0, 999)
            player:GossipSendMenu(90132, object, MenuId)
            object:SendUnitSay("Que voudriez-vous apprendre ?", 0)
            object:Emote(1)
        end
        if (intid == 18) then
            player:AdvanceSkill(171, 450)
            player:AdvanceSkill(164, 450)
            player:AdvanceSkill(333, 450)
            player:AdvanceSkill(202, 450)
            player:AdvanceSkill(182, 450)
            player:AdvanceSkill(773, 450)
            player:AdvanceSkill(755, 450)
            player:AdvanceSkill(165, 450)
            player:AdvanceSkill(186, 450)
            player:AdvanceSkill(393, 450)
            player:AdvanceSkill(197, 450)
            player:AdvanceSkill(185, 450)
            player:AdvanceSkill(129, 450)
            player:AdvanceSkill(356, 450)
            player:GossipComplete()
            object:SendUnitSay("Voilà qui est fait, vous savez désormais maîtriser ce que vous avez appris", 0)
            object:Emote(1)
        end
        if (intid == 100) then -- Alchimie
            player:GossipMenuAddItem(0, "Je souhaiterais oublier ce métier", 0, 158)
            player:GossipMenuAddItem(0, "Menu des métiers", 0, 17)
            player:GossipSendMenu(90133, object, MenuId)
            ------------------------
            player:LearnSpell(51303)
            player:LearnSpell(58871)
            player:LearnSpell(58868)
            player:LearnSpell(60403)
            player:LearnSpell(60396)
            player:LearnSpell(60405)
            player:LearnSpell(57427)
            player:LearnSpell(57425)
            player:LearnSpell(60350)
            player:LearnSpell(53840)
            player:LearnSpell(53898)
            player:LearnSpell(54218)
            player:LearnSpell(60367)
            player:LearnSpell(53847)
            player:LearnSpell(53903)
            player:LearnSpell(54213)
            player:LearnSpell(53902)
            player:LearnSpell(53901)
            player:LearnSpell(53848)
            player:LearnSpell(53839)
            player:LearnSpell(53905)
            player:LearnSpell(53899)
            player:LearnSpell(53900)
            player:LearnSpell(53812)
            player:LearnSpell(53838)
            player:LearnSpell(53836)
            player:LearnSpell(53837)
            player:LearnSpell(53842)
            player:LearnSpell(53841)
            player:LearnSpell(53042)
            player:LearnSpell(60893)
            object:SendUnitSay("L'alchimie, un métier passionnant pour qui sais fabriquer des potions", 0)
            object:Emote(1)
    end
     
    if (intid == 101) then -- Forge
     
            player:GossipMenuAddItem(0, "Je souhaiterais oublier ce métier", 0, 160)
            player:GossipMenuAddItem(0, "Menu des métiers", 0, 17)
            player:GossipSendMenu(90134, object, MenuId)
            ------------------------
            player:LearnSpell(51298)
            player:LearnSpell(55374)
            player:LearnSpell(55377)
            player:LearnSpell(55372)
            player:LearnSpell(55375)
            player:LearnSpell(55373)
            player:LearnSpell(55376)
            player:LearnSpell(55370)
            player:LearnSpell(55369)
            player:LearnSpell(55371)
            player:LearnSpell(56234)
            player:LearnSpell(56400)
            player:LearnSpell(59406)
            player:LearnSpell(61008)
            player:LearnSpell(55303)
            player:LearnSpell(55302)
            player:LearnSpell(56555)
            player:LearnSpell(56554)
            player:LearnSpell(56556)
            player:LearnSpell(55304)
            player:LearnSpell(55311)
            player:LearnSpell(55310)
            player:LearnSpell(55312)
            player:LearnSpell(61009)
            player:LearnSpell(61010)
            player:LearnSpell(56357)
            player:LearnSpell(55839)
            player:LearnSpell(55732)
            player:LearnSpell(55656)
            object:SendUnitSay("La forge, un métier passionnant pour qui sais manier le marteau", 0)
            object:Emote(1)
    end
     
    if (intid == 102) then -- Enchantement

            player:GossipMenuAddItem(0, "Je souhaiterais oublier ce métier", 0, 162)
            player:GossipMenuAddItem(0, "Menu des métiers", 0, 17)
            player:GossipSendMenu(90135, object, MenuId)
            ------------------------
            player:LearnSpell(51312)
            player:LearnSpell(60619)
            player:LearnSpell(47900)
            player:LearnSpell(60668)
            player:LearnSpell(44593)
            player:LearnSpell(44509)
            player:LearnSpell(60663)
            player:LearnSpell(44489)
            player:LearnSpell(44589)
            player:LearnSpell(44598)
            player:LearnSpell(44529)
            player:LearnSpell(44508)
            player:LearnSpell(44488)
            player:LearnSpell(44633)
            player:LearnSpell(44510)
            player:LearnSpell(44584)
            player:LearnSpell(44484)
            player:LearnSpell(44616)
            player:LearnSpell(47766)
            player:LearnSpell(44645)
            player:LearnSpell(44636)
            player:LearnSpell(59636)
            player:LearnSpell(44635)
            player:LearnSpell(44492)
            player:LearnSpell(44500)
            player:LearnSpell(44513)
            player:LearnSpell(60653)
            player:LearnSpell(44629)
            player:LearnSpell(44582)
            player:LearnSpell(44630)
            player:LearnSpell(60623)
            player:LearnSpell(44528)
            player:LearnSpell(60621)
            player:LearnSpell(60606)
            player:LearnSpell(44555)
            player:LearnSpell(44506)
            player:LearnSpell(32667)
            player:LearnSpell(44623)
            player:LearnSpell(60616)
            player:LearnSpell(44592)
            player:LearnSpell(27958)
            player:LearnSpell(60609)
            object:SendUnitSay("L'enchantement, un métier passionnant pour qui sais maîtriser le pouvoir arcanique", 0)
            object:Emote(1)
    end
     
    if (intid == 103) then -- Ingénierie
    
            player:GossipMenuAddItem(0, "Je souhaiterais oublier ce métier", 0, 164)
            player:GossipMenuAddItem(0, "Menu des métiers", 0, 17)
            player:GossipSendMenu(90136, object, MenuId)
            ------------------------
            player:LearnSpell(51305)
            player:LearnSpell(56479)
            player:LearnSpell(60874)
            player:LearnSpell(56462)
            player:LearnSpell(56478)
            player:LearnSpell(56469)
            player:LearnSpell(56472)
            player:LearnSpell(56470)
            player:LearnSpell(56467)
            player:LearnSpell(56466)
            player:LearnSpell(61483)
            player:LearnSpell(56477)
            player:LearnSpell(56475)
            player:LearnSpell(56476)
            player:LearnSpell(56474)
            player:LearnSpell(56468)
            player:LearnSpell(55016)
            player:LearnSpell(54353)
            player:LearnSpell(54998)
            player:LearnSpell(54999)
            player:LearnSpell(63770)
            player:LearnSpell(61471)
            player:LearnSpell(56471)
            player:LearnSpell(54736)
            player:LearnSpell(55002)
            player:LearnSpell(54793)
            player:LearnSpell(63765)
            player:LearnSpell(56463)
            player:LearnSpell(56461)
            player:LearnSpell(56459)
            player:LearnSpell(56464)
            object:SendUnitSay("L'ingènierie, un métier passionnant pour qui sais manier la clé plate", 0)
            object:Emote(1)
    end
     
    if (intid == 104) then -- Herboristerie
     
            player:GossipMenuAddItem(0, "Je souhaiterais oublier ce métier", 0, 166)
            player:GossipMenuAddItem(0, "Menu des métiers", 0, 17)
            player:GossipSendMenu(90137, object, MenuId)
            ------------------------
            player:LearnSpell(50301)
            object:SendUnitSay("L'herboristerie, un métier de récolte fort interessant", 0)
            object:Emote(1)
    end
     
    if (intid == 105) then -- Calligraphie
     
            player:GossipMenuAddItem(0, "Je souhaiterais oublier ce métier", 0, 168)
            player:GossipMenuAddItem(0, "Menu des métiers", 0, 17)
            player:GossipSendMenu(90138, object, MenuId)
            ------------------------
            player:LearnSpell(45380)
            player:LearnSpell(58483)
            player:LearnSpell(58491)
            player:LearnSpell(50604)
            player:LearnSpell(50611)
            player:LearnSpell(59504)
            player:LearnSpell(59498)
            player:LearnSpell(59497)
            player:LearnSpell(50620)
            player:LearnSpell(59501)
            player:LearnSpell(61117)
            player:LearnSpell(61118)
            player:LearnSpell(61119)
            player:LearnSpell(61120)
            player:LearnSpell(61177)
            player:LearnSpell(57715)
            player:LearnSpell(60337)
            object:SendUnitSay("La calligraphie, un métier passionnant pour qui sais manier la plume", 0)
            object:Emote(1)
    end
     
     
    if (intid == 106) then -- Joaillerie
     
            player:GossipMenuAddItem(0, "Je souhaiterais oublier ce métier", 0, 170)
            player:GossipMenuAddItem(0, "Menu des métiers", 0, 17)
            player:GossipSendMenu(90139, object, MenuId)
            ------------------------
            player:LearnSpell(51310)
            player:LearnSpell(56197)
            player:LearnSpell(55402)
            player:LearnSpell(55399)
            player:LearnSpell(55394)
            player:LearnSpell(55386)
            player:LearnSpell(56203)
            player:LearnSpell(59759)
            player:LearnSpell(56199)
            player:LearnSpell(56202)
            player:LearnSpell(56201)
            player:LearnSpell(53969)
            player:LearnSpell(53947)
            player:LearnSpell(53956)
            player:LearnSpell(54007)
            player:LearnSpell(56531)
            player:LearnSpell(53989)
            player:LearnSpell(53953)
            object:SendUnitSay("La joaillerie, un métier passionnant pour qui sais manier la meule", 0)
            object:Emote(1)
    end
     
    if (intid == 107) then -- Travail du cuir
     
            player:GossipMenuAddItem(0, "Je souhaiterais oublier ce métier", 0, 172)
            player:GossipMenuAddItem(0, "Menu des métiers", 0, 17)
            player:GossipSendMenu(90140, object, MenuId)
            ------------------------
            player:LearnSpell(51301)
            player:LearnSpell(60640)
            player:LearnSpell(60637)
            player:LearnSpell(50965)
            player:LearnSpell(50967)
            player:LearnSpell(60643)
            player:LearnSpell(60583)
            player:LearnSpell(57683)
            player:LearnSpell(57691)
            player:LearnSpell(57690)
            object:SendUnitSay("Le travail du cuir, un métier passionnant pour qui sais manier le cuir", 0)
            object:Emote(1)
    end
     
    if (intid == 108) then -- Minage

            player:GossipMenuAddItem(0, "Je souhaiterais oublier ce métier", 0, 174)
            player:GossipMenuAddItem(0, "Menu des métiers", 0, 17)
            player:GossipSendMenu(90141, object, MenuId)
            ------------------------
            player:LearnSpell(50309)
            object:SendUnitSay("Le minage, un métier de récolte fort interessant", 0)
            object:Emote(1)
    end
     
    if (intid == 109) then -- Dépeçage
     
            player:GossipMenuAddItem(0, "Je souhaiterais oublier ce métier", 0, 176)
            player:GossipMenuAddItem(0, "Menu des métiers", 0, 17)
            player:GossipSendMenu(90142, object, MenuId)
            -------------------------
            player:LearnSpell(50307)
            object:SendUnitSay("Le dépeçage, un métier de récolte fort interessant", 0)
            object:Emote(1)
    end
     
    if (intid == 110) then -- Couture
     
            player:GossipMenuAddItem(0, "Je souhaiterais oublier ce métier", 0, 178)
            player:GossipMenuAddItem(0, "Menu des métiers", 0, 17)
            player:GossipSendMenu(90143, object, MenuId)
            ------------------------
            player:LearnSpell(51308)
            player:LearnSpell(56026)
            player:LearnSpell(56024)
            player:LearnSpell(56028)
            player:LearnSpell(56027)
            player:LearnSpell(56025)
            player:LearnSpell(56029)
            player:LearnSpell(60993)
            player:LearnSpell(60971)
            player:LearnSpell(60994)
            player:LearnSpell(60990)
            player:LearnSpell(55769)
            player:LearnSpell(55642)
            player:LearnSpell(55777)
            player:LearnSpell(56002)
            player:LearnSpell(56001)
            player:LearnSpell(56003)
            player:LearnSpell(56007)
            player:LearnSpell(60969)
            object:SendUnitSay("La couture, un métier passionnant pour qui sais manier l'aiguille", 0)
            object:Emote(1)
    end
     
     
    if (intid == 111) then -- Métiers secondaire
            player:GossipMenuAddItem(5, "Cuisine", 0, 179)
            player:GossipMenuAddItem(5, "Secourisme", 0, 180)
            player:GossipMenuAddItem(5, "Pêche", 0, 181)
            player:GossipMenuAddItem(0, "Menu des métiers", 0, 17)
            player:GossipMenuAddItem(0, "Menu principal", 0, 999)
            player:GossipSendMenu(90132, object, MenuId)
    end
         
    if (intid == 157) then -- Alchimie
            player:GossipComplete() 
    end
     
    if (intid == 158) then -- Oublier
            player:RemoveSpell(51303)
            player:RemoveSpell(51304)
            player:RemoveSpell(53042)
            player:GossipComplete()
            object:SendUnitSay("Ce métier ne vous a pas plu ?$bUn autre vous plaira sûrement", 0)
            object:Emote(1)
    end
     
    if (intid == 159) then -- Forge
            player:GossipComplete()
    end
     
    if (intid == 160) then -- Oublier
            player:RemoveSpell(51298)
            player:RemoveSpell(51300)
            player:GossipComplete()
            object:SendUnitSay("Ce métier ne vous a pas plu ?$bUn autre vous plaira sûrement", 0)
            object:Emote(1)
    end
     
    if (intid == 161) then -- Enchantement
           player:GossipComplete()
    end
     
    if (intid == 162) then -- Oublier
            player:RemoveSpell(51312)
            player:RemoveSpell(51313)
            player:GossipComplete()
            object:SendUnitSay("Ce métier ne vous a pas plu ?$bUn autre vous plaira sûrement", 0)
            object:Emote(1)
    end
     
    if (intid == 163) then -- Ingénieurie
            player:GossipComplete()
    end
     
    if (intid == 164) then -- Oublier
            player:RemoveSpell(51305)
            player:RemoveSpell(51306)
            player:GossipComplete()
            object:SendUnitSay("Ce métier ne vous a pas plu ?$bUn autre vous plaira sûrement", 0)
            object:Emote(1)
    end
     
    if (intid == 165) then -- Herboristerie
            player:GossipComplete()
    end
     
    if (intid == 166) then -- Oublier
            player:RemoveSpell(50300)
            player:RemoveSpell(50301)
            player:GossipComplete()
            object:SendUnitSay("Ce métier ne vous a pas plu ?$bUn autre vous plaira sûrement", 0)
            object:Emote(1)
    end
     
    if (intid == 167) then -- Calligraphie
            player:GossipComplete()
    end
     
    if (intid == 168) then -- Oublier
            player:RemoveSpell(45363)
            player:RemoveSpell(45380)
            player:GossipComplete()
            object:SendUnitSay("Ce métier ne vous a pas plu ?$bUn autre vous plaira sûrement", 0)
            object:Emote(1)
    end
     
    if (intid == 169) then -- Joaillerie
            player:GossipComplete()
    end
     
    if (intid == 170) then -- Oublier
            player:RemoveSpell(51310)
            player:RemoveSpell(51311)
            player:GossipComplete()
            object:SendUnitSay("Ce métier ne vous a pas plu ?$bUn autre vous plaira sûrement", 0)
            object:Emote(1)
    end
     
    if (intid == 171) then -- Travail du Cuir
            player:GossipComplete()
    end
     
    if (intid == 172) then -- Oublier
            player:RemoveSpell(51301)
            player:RemoveSpell(51302)
            player:GossipComplete()
            object:SendUnitSay("Ce métier ne vous a pas plu ?$bUn autre vous plaira sûrement", 0)
            object:Emote(1)
    end
     
    if (intid == 173) then -- Minage
            player:GossipComplete()
    end
     
    if (intid == 174) then -- Oublier
            player:RemoveSpell(50309)
            player:RemoveSpell(50310)
            player:GossipComplete()
            object:SendUnitSay("Ce métier ne vous a pas plu ?$bUn autre vous plaira sûrement", 0)
            object:Emote(1)
    end
     
    if (intid == 175) then -- Dépeçage
            player:GossipComplete()
    end
     
    if (intid == 176) then -- Oublier
            player:RemoveSpell(50305)
            player:RemoveSpell(50306)
            player:GossipComplete()
            object:SendUnitSay("Ce métier ne vous a pas plu ?$bUn autre vous plaira sûrement", 0)
            object:Emote(1)
    end
     
    if (intid == 177) then -- Couture
            player:GossipComplete()
    end
     
    if (intid == 178) then -- Oublier
            player:RemoveSpell(51308)
            player:RemoveSpell(51309)
            player:GossipComplete()
            object:SendUnitSay("Ce métier ne vous a pas plu ?$bUn autre vous plaira sûrement", 0)
            object:Emote(1)
    end
     
    if (intid == 179) then -- Cuisine
            player:GossipMenuAddItem(0, "Je souhaiterais oublier ce métier", 0, 183)
            player:GossipMenuAddItem(0, "Menu des métiers", 0, 17)
            player:GossipSendMenu(90144, object, MenuId)
            ------------------------
            player:LearnSpell(51295)
    end
     
    if (intid == 180) then -- Secourisme
            player:GossipMenuAddItem(0, "Je souhaiterais oublier ce métier", 0, 185)
            player:GossipMenuAddItem(0, "Menu des métiers", 0, 17)
            player:GossipSendMenu(90145, object, MenuId)
            ------------------------
            player:LearnSpell(50299)
    end
     
    if (intid == 181) then -- Pêche
            player:GossipMenuAddItem(0, "Je souhaiterais oublier ce métier", 0, 187)
            player:GossipMenuAddItem(0, "Menu des métiers", 0, 17)
            player:GossipSendMenu(90146, object, MenuId)
            ------------------------
            player:LearnSpell(51293)
    end

    if (intid == 182) then -- Cuisine
     
            player:GossipComplete()
    end
     
    if (intid == 183) then -- Oublier
            player:RemoveSpell(51296)
            player:RemoveSpell(51295)
            player:GossipComplete()
            object:SendUnitSay("Ce métier ne vous a pas plu ?$bUn autre vous plaira sûrement", 0)
            object:Emote(1)
    end
     
    if (intid == 184) then -- Secourisme
            player:GossipComplete()
    end
     
    if (intid == 185) then -- Oublier
            player:RemoveSpell(50299)
            player:RemoveSpell(45442)
            player:GossipComplete()
            object:SendUnitSay("Ce métier ne vous a pas plu ?$bUn autre vous plaira sûrement", 0)
            object:Emote(1)
    end
     
    if (intid == 186) then -- Pêche
            player:GossipComplete()
    end
     
    if (intid == 187) then -- Oublier
            player:RemoveSpell(51294)
            player:RemoveSpell(51293)
            player:GossipComplete()
            object:SendUnitSay("Ce métier ne vous a pas plu ?$bUn autre vous plaira sûrement", 0)
            object:Emote(1)
    end
end

RegisterCreatureGossipEvent(npcid, 1, OnGossipHello)
RegisterCreatureGossipEvent(npcid, 2, OnGossipSelect)